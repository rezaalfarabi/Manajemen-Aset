@extends('backend.template')

@section('content-header')

@endsection

@section('content')
<p> Ini halaman Home </p>
@endsection