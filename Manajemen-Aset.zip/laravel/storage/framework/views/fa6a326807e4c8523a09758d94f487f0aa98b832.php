
<table id="example1" class="table table-bordered table-striped table-response">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama User</th>
            <th>Tanggal</th>
            <th>Type Permohonan</th>
            <th>Deskripsi</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $permohonan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $permohonan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no+1); ?></td>
            <td><?php echo e($permohonan->nama); ?></td>
            <td><?php echo e($permohonan->tgl_permohonan); ?></td>
            <td><?php echo e($permohonan->permohonan); ?></td>
            <td><?php echo e($permohonan->deskripsi); ?></td>
            <td>
                <?php if(session('level') == 2): ?>
                    <?php if($permohonan->status == 0): ?>
                        <button onclick="status('<?php echo e($permohonan->id_permohonan); ?>', 1)" class="fa fa-check-circle badge badge-danger">Waiting</button>
                    <?php else: ?>
                        <button onclick="status('<?php echo e($permohonan->id_permohonan); ?>', 0)" class="fa fa-check-circle badge badge-success">Approve</button>   
                    <?php endif; ?>
                <?php else: ?>
                    <?php if($permohonan->status == 0): ?>
                        <button class="fa fa-check-circle badge badge-danger">Waiting</button>
                    <?php else: ?>
                        <button class="fa fa-check-circle badge badge-success">Approve</button>   
                    <?php endif; ?>
                <?php endif; ?>
            </td>
            <?php if(session('level') == 1): ?>
            <td>
                <button onclick="update(
                    '<?php echo e($permohonan->id_permohonan); ?>',
                    '<?php echo e($permohonan->nama); ?>',
                    '<?php echo e($permohonan->tgl_permohonan); ?>',
                    '<?php echo e($permohonan->permohonan); ?>',
                    '<?php echo e($permohonan->deskripsi); ?>'
                )" type="button" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i>Edit</button>
                <button type="button" onclick="hapus('<?php echo e($permohonan->id_permohonan); ?>')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Delete</a>
            </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\laravel_base\Manajemen-Aset\resources\views/backend/page/permohonan/datatable.blade.php ENDPATH**/ ?>