<!DOCTYPE html>
<html lang="en">
    <!-- include dibawah memanggil file header yg ada pada folder component -->
  <?php echo $__env->make('backend.component.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">

<!-- file jquery dan file javascript -->
  <?php echo $__env->make('backend.component.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
  <!-- Menu Navbar -->
  <?php echo $__env->make('backend.component.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->

  <!-- Menu Sidebar / Navigator Menu -->
  <?php echo $__env->make('backend.component.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content -->
  <div class="content-wrapper">
    <?php echo $__env->yieldContent('content-header'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- yield dibawah berfungsi menampilkan halaman secara dinamis -->
        <?php echo $__env->yieldContent('content'); ?>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content -->

  <!-- Menu Footer -->
  <?php echo $__env->make('backend.component.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


</body>
</html>
<?php /**PATH D:\laravel_base\Manajemen-Aset\resources\views/backend/template.blade.php ENDPATH**/ ?>