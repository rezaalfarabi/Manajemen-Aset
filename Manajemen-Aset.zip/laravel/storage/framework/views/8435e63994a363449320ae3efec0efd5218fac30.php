
<table id="example1" class="table table-bordered table-striped table-response">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Aset</th>
            <th>Serial Number</th>
            <th>NUP</th>
            <th>Kategori</th>
            <th>Tahun Pengadaan</th>
            <th>Qty</th>
            <th>Satuan </th>
            <th>Nama Penerima</th>
            <th>Department/Lokasi</th>
            <th>Status</th>
            <?php if(session('level') == 1): ?>
            <th>Action</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $aset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $aset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no+1); ?></td>
            <td><?php echo e($aset->nama_aset); ?></td>
            <td><?php echo e($aset->serial_number); ?></td>
            <td><?php echo e($aset->nup); ?></td>
            <td><?php echo e($aset->kategori_nama); ?></td>
            <td><?php echo e($aset->tahun_pengadaan); ?></td>
            <td><?php echo e($aset->qty); ?></td>
            <td><?php echo e($aset->satuan_nama); ?></td>
            <td><?php echo e($aset->nama_pegawai); ?></td>
            <td><?php echo e($aset->departement_nama); ?></td>
            <td>
                <?php if($aset->status == 0): ?>
                <button onclick="status('<?php echo e($aset->id_aset); ?>', 1)" class="fa fa-check-circle badge badge-danger"> Not Ready</button>
                    <?php else: ?>
                <button onclick="status('<?php echo e($aset->id_aset); ?>', 0)" class="fa fa-check-circle badge badge-success"> Ready</button>   
                <?php endif; ?>
            </td>
            <?php if(session('level') == 1): ?>
            <td>
                <button onclick="update(
                    '<?php echo e($aset->id_aset); ?>',
                    '<?php echo e($aset->nama_aset); ?>',
                    '<?php echo e($aset->serial_number); ?>',
                    '<?php echo e($aset->nup); ?>',
                    '<?php echo e($aset->kategori_id); ?>',
                    '<?php echo e($aset->tahun_pengadaan); ?>',
                    '<?php echo e($aset->qty); ?>',
                    '<?php echo e($aset->satuan_id); ?>',
                    '<?php echo e($aset->nama_pegawai); ?>',
                    '<?php echo e($aset->departement_id); ?>',
                )" type="button" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i>Edit</button>
                <button type="button" onclick="hapus('<?php echo e($aset->id_aset); ?>')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Delete</a>
            </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\laravel_base\Manajemen-Aset\resources\views/backend/page/dataaset/datatable.blade.php ENDPATH**/ ?>