
<table id="example1" class="table table-bordered table-striped table-response">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Department</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $departement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $departement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no+1); ?></td>
                            <td><?php echo e($departement->departement_nama); ?></td>
                            <td>
                                <button onclick="update(
                                    '<?php echo e($departement->departement_id); ?>',
                                    '<?php echo e($departement->departement_nama); ?>'
                                )" type="button" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i>Edit</button>
                               <button type="button" onclick="hapus('<?php echo e($departement->departement_id); ?>')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Delete</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table><?php /**PATH D:\laravel_base\Manajemen-Aset\resources\views/backend/page/departement/dataDepartement.blade.php ENDPATH**/ ?>