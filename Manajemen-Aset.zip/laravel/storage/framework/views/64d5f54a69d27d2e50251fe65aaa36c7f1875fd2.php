
 
<?php $__env->startSection('content'); ?>
    <div class="row py-2">
        <div class="col-md-12">
        <?php if(session('pesan')): ?>
            <div style="display:none" id="pesan" class="alert alert-success">
            <?php echo e(session('pesan')); ?>

            </div>
        <?php endif; ?>
        <div class="card card-outline card-primary">
            <div class="card-header">
                
                <div class="float-left">
                    <h3>Data Aset</h3>
                </div>

                <div class="float-right">
                    <button onclick="add()" type='button' class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Add</button>
                </div>
            </div>

            <div class="card-body" id="isi"></div>
        </div>
    </div>
    </div>

    <!-- Modal -->
<div id="asetAdd" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title"> Aset</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
            <div class="modal-body">
                    <div class="row">
                    <!-- kiri -->
                      <div class="col-md-6">
                      <input type="hidden" name="id_aset" id="id_aset">

                        <div class="form-group">
                            <label for="">Nama Aset</label>
                            <input type="text" name="nama_aset" id="nama_aset" class="form-control <?php $__errorArgs = ['nama_aset'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nama Aset"> 
                        </div>

                        <div class="form-group">
                            <label for="">Serial Number</label>
                            <input type="text" name="serial_number" id="serial_number" class="form-control" placeholder="Serial Number"> 
                        </div>

                        <div class="form-group">
                            <label for="">NUP</label>
                            <input type="number" name="nup" id="nup" class="form-control" placeholder="No Urut Pencatatan"> 
                        </div>

                        <div class="form-group">
                            <label for="">Qty</label>
                            <input type="number" name="qty" id="qty" class="form-control <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Qty"> 
                        </div>

                        <div class="form-group">
                            <label for="">Nama Penerima</label>
                            <input type="text" name="nama_pegawai" id="nama_pegawai" class="form-control" placeholder="Nama Penerima"> 
                        </div>
                      </div>
                    <!-- kanan -->
                     <div class="col-md-6">
                     <!-- <select id='date-dropdown'></select> -->

                        <div class="form-group">
                            <label for="">Tahun Pengadaan</label>
                            <select name="tahun_pengadaan" id="tahun_pengadaan"  class="form-control">
                                <option>-- Pilih --</option>
                            </select> 
                        </div>

                        <div class="form-group">
                            <label for="">Kategori</label>
                            <select name="kategori_id" id="kategori_id" class="form-control <?php $__errorArgs = ['kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">-- Pilih --</option>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kategori->kategori_id); ?>"><?php echo e($kategori->kategori_nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
                        </div>

                        <div class="form-group">
                            <label for="">Satuan </label>
                            <select name="satuan_id" id="satuan_id" class="form-control <?php $__errorArgs = ['satuan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">-- Pilih --</option>
                                <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($satuan->satuan_id); ?>"><?php echo e($satuan->satuan_nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
                        </div>

                        <div class="form-group">
                            <label for="">Department/Lokasi</label>
                            <select name="departement_id" id="departement_id" class="form-control <?php $__errorArgs = ['departement_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">-- Pilih --</option>
                                <?php $__currentLoopData = $departement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($departement->departement_id); ?>"><?php echo e($departement->departement_nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
                        </div>
                     </div>
                    </div>
                   
                    <div align="right">
                        <button type="button" onclick="save()" class="btn btn-outline-primary">Save</button>
                        <button type="button" onclick="kosong()" class="btn btn-outline-warning">Reset</button>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="kosong()" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<!-- fungsi untuk menampilkan dan hidden & setinterval dengan menggunakan bootstrap alert -->
<?php if(session('pesan')): ?>
<script>
    $('#pesan').show()
    setInterval(function() {
        $('#pesan').hide()
    }, 4000);
</script>
<?php endif; ?>

<!-- fungsi untuk menambah data dengan menggunakan jquery -->
<script>
    $(document).ready(function(){
       $('#isi').load('/data-table');
    })

    function add() 
    {
        $('#asetAdd').modal();
    }

// fungsi untuk mengubah data dengan menggunakan vanilla javascript
    function update(id, nama_aset, serial_number, nup, kategori, tahun_pengadaan, qty, satuan, nama_pegawai, departement) 
    {
        // alert(nama)
        document.getElementById('id_aset').value = id;
        document.getElementById('nama_aset').value = nama_aset;
        document.getElementById('serial_number').value = serial_number;
        document.getElementById('nup').value =  nup;
        document.getElementById('kategori_id').value = kategori;
        document.getElementById('tahun_pengadaan').value = tahun_pengadaan;
        document.getElementById('qty').value = qty;
        document.getElementById('satuan_id').value = satuan;
        document.getElementById('nama_pegawai').value = nama_pegawai;
        document.getElementById('departement_id').value = departement;
        $('#asetAdd').modal();
    }

    // fungsi untuk simpan data aset menggunakan jquery ajax
    function save()
    {
        var id_aset = $('#id_aset').val()
        var nama_aset = $('#nama_aset').val()
        var serial_number = $('#serial_number').val()
        var nup = $('#nup').val()
        var qty = $('#qty').val()
        var nama_pegawai = $('#nama_pegawai').val()
        var tahun_pengadaan = $('#tahun_pengadaan').val()
        var kategori_id = $('#kategori_id').val()
        var satuan_id = $('#satuan_id').val()
        var departement_id = $('#departement_id').val()

        $.ajax({
            url: '/data-aset-simpan',
            type: 'POST',
            data: {
                '_token': '<?php echo e(csrf_token()); ?>',
                'id_aset': id_aset,
                'nama_aset': nama_aset,
                'serial_number': serial_number,
                'nup' : nup,
                'qty': qty,
                'nama_pegawai': nama_pegawai,
                'tahun_pengadaan': tahun_pengadaan,
                'kategori_id': kategori_id,
                'satuan_id': satuan_id,
                'departement_id': departement_id,
            },
            dataType: 'JSON',
            success: function(data)
            {
                // console.log(data)
                $('#asetAdd').modal('hide');
                $('#isi').load('/data-table');
                    toastr.success(data.message, data.title, {
                    delay: 5000,
                    fadeOut: 4000,
                });
                kosong()
            }
        })
    }

    // fungsi untuk clear input
    function kosong()
    {
        $('#id_aset').val('')
        $('#nama_aset').val('')
        $('#serial_number').val('')
        $('#qty').val('')
        $('#nup').val('')
        $('#nama_pegawai').val('')
        $('#tahun_pengadaan').val('')
        $('#kategori_id').val('')
        $('#satuan_id').val('')
        $('#departement_id').val('')
    }

// fungsi untuk melihat status menggunakan jquery ajax
    function status(id_aset, status) 
    {
        $.ajax({
            url: '/data-aset-status',
            type: 'post',
            data: {
                'id_aset' : id_aset,
                'status' : status,
                '_token' : '<?php echo e(csrf_token()); ?>'
            },
            dataType : 'json',
            success : function(data) 
            {
                $('#isi').load('/data-table');
                    toastr.success(data.message, data.title, {
                    delay: 5000,
                    fadeOut: 4000,
                });
            }
            
        })
    } 

    // fungsi untuk menghapus data menggunakan sweet alert dan toast js
    // function deleteConfirmation(id_aset) {
    //     swal({
    //         title: "Hapus?",
    //         text: "Anda yakin ingin menghapus data ini?",
    //         type: "warning",
    //         showCancelButton: !0,
    //         confirmButtonText: "Ya, Hapus!",
    //         cancelButtonText: "Tidak, Batalkan!",
    //         reverseButtons: !0
    //     }).then(function (e) {
    //         if (e.value === true) {
    //             // var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

    //             $.ajax({
    //                 type: 'POST',
    //                 url: "<?php echo e(url('/hapus')); ?>/" + id_aset,
    //                 data: {'_token': '<?php echo e(csrf_token()); ?>'},
    //                 dataType: 'JSON',
    //                 success: function (data) {
    //                     console.log(data)
    //                     if (data.success === true) {
    //                         swal("Done!", data.message, "success");
    //                     } else {
    //                         swal("Error!", data.message, "error");
    //                     }
                        
    //                     toastr.success(data.message, data.title, {
    //                         delay: 5000,
    //                         fadeOut: 4000,
    //                     }); 
    //                     $('#isi').load('/data-table');
    //                 }
    //             });

    //         } else {
    //             e.dismiss;
    //         }

    //     }, function (dismiss) {
    //         return false;
    //     })
    // }

    function hapus(id_aset) {
        $.ajax({
            url : '/data-aset-hapus',
            type : 'POST',
            data : {
                '_token' : '<?php echo e(csrf_token()); ?>',
                'id_aset' : id_aset
            },
            dataType : 'JSON',
            success : function(data) {
                console.log(data)
                toastr.success(data.message, data.title, {
                            delay: 5000,
                            fadeOut: 4000,
                        }); 
                $('#isi').load('/data-table')
            }
        })
    }

    // fungsi untuk menampilkan tahun
    let dateDropdown = document.getElementById('tahun_pengadaan'); 
        let currentYear = new Date().getFullYear();    
        let earliestYear = 1970;     
        while (currentYear >= earliestYear) {      
        let dateOption = document.createElement('option');          
        dateOption.text = currentYear;      
        dateOption.value = currentYear;        
        dateDropdown.add(dateOption);      
        currentYear -= 1;    
   }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_base\Manajemen-Aset\resources\views/backend/page/dataaset/index.blade.php ENDPATH**/ ?>